function disp()
{ 
alert("javascript");
}