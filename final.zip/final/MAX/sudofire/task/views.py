from django.shortcuts import render
from task.models import Contact,Customer
# Create your views here.

def home(request):
    context = {'name':'Mayank', 'Department':'MCA'}
    return render(request, 'home.html',context)



def contact(request):
    if request.method=="POST":
        FName =  request.POST['FName']
        LName =  request.POST['LName']
        phone =  request.POST['phone']
        email =  request.POST['email']
        
        ins = Contact(FName=FName, LName=LName, phone=phone, email=email)
        ins.save()
  
        print("data has been written to the db")
    return render(request, 'contact.html')


def customer(request):
    if request.method =="POST":
        PNumber = request.POST['PNumber']
        ins1 = Customer(PNumber)
        ins1.save()
  
        print("data has been written to the db")
    return render(request, 'customer.html')