from django.contrib import admin
from task.models import Contact,Customer
# Register your models here.
admin.site.register(Contact)
admin.site.register(Customer)