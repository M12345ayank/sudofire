
from typing import TYPE_CHECKING

from django.db import models
if TYPE_CHECKING:
    from task.models import Contact,Customer

class Contact(models.Model):
    FName = models.CharField(max_length=30)
    LName = models.CharField(max_length=30)
    phone = models.CharField(max_length=10, unique=True)
    email = models.EmailField(unique=True)


class Customer(models.Model):
    PNumber = models.CharField(max_length=10)

